# Project-Rapid-Rido
Simple DHTML web site for starting small business

The image files included in this directory are free software. It is licensed under the GNU GPL version 3 or later. If you share this program or your modifications you must grant the recipients the same freedoms. To be more specific: you must share the source code under the same license. For details see : http://www.gnu.org/licenses/gpl-3.0.html
Copyright (C) 2022
Original author: Themefarmer
Author's website: https://themefarmer.com/
E-mail: support@themefarmer.com

Contents - List of files: 
- slide1.png
- slide2.png
- slide3.png
- slideA.png
- slideB.png
- slideC.png